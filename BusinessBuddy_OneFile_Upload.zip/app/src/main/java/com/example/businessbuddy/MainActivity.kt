package com.example.businessbuddy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private val Pink = androidx.compose.ui.graphics.Color(0xFFE85D9E)
private val PalePink = androidx.compose.ui.graphics.Color(0xFFFFF0F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BusinessBuddyApp() }
    }
}

@Composable
fun BusinessBuddyApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pink,
            secondary = androidx.compose.ui.graphics.Color(0xFF7357A6),
            surface = PalePink
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Business Buddy", fontWeight = FontWeight.Bold)
                            Text("Start small. Grow smart. 💕", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Profit", "Ideas").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(if (i == 0) "⌂" else if (i == 1) "₦" else "💡") },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(pad))
                1 -> ProfitScreen(Modifier.padding(pad))
                else -> IdeasScreen(Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Welcome! 💕", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Your simple starter toolkit for running a small business.")
        InfoCard("💰 Profit Calculator", "Work out your estimated profit before you sell.")
        InfoCard("📊 Sales Tracking", "Keep a simple record of sales and expenses.")
        InfoCard("💡 Business Ideas", "Browse beginner-friendly ideas by budget.")
        Spacer(Modifier.height(8.dp))
        Text("Tip", fontWeight = FontWeight.Bold)
        Text("Don't treat every naira you receive as profit. First subtract the costs connected to the sale.")
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PalePink),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(body)
        }
    }
}

@Composable
fun ProfitScreen(modifier: Modifier = Modifier) {
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }

    val c = cost.toDoubleOrNull() ?: 0.0
    val p = price.toDoubleOrNull() ?: 0.0
    val q = qty.toDoubleOrNull() ?: 0.0
    val profitEach = p - c
    val totalProfit = profitEach * q

    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Profit Calculator 💰", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Enter your cost price, selling price and quantity.")

        OutlinedTextField(cost, { cost = it }, label = { Text("Cost per item (₦)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(price, { price = it }, label = { Text("Selling price per item (₦)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(qty, { qty = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = PalePink)) {
            Column(Modifier.padding(18.dp)) {
                Text("Estimated profit per item", fontWeight = FontWeight.Bold)
                Text("₦${money(profitEach)}", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text("Estimated total profit")
                Text("₦${money(totalProfit)}", style = MaterialTheme.typography.headlineMedium, color = Pink)
            }
        }
        Text("Formula: Selling price − cost = profit per item.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun IdeasScreen(modifier: Modifier = Modifier) {
    val ideas = listOf(
        "Jewelry & accessories — ₦10k–₦30k",
        "Hair accessories — ₦10k–₦25k",
        "Snacks & treats — ₦10k–₦25k",
        "Gift packaging — ₦10k–₦25k",
        "Canva design services — ₦0–₦10k",
        "Writing/caption services — ₦0–₦10k",
        "Digital planners — ₦0–₦10k",
        "Phone accessories — ₦20k–₦30k",
        "Beaded items — ₦10k–₦30k",
        "Mini gift bundles — ₦15k–₦30k"
    )
    LazyColumn(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Business Ideas 💡", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Example starting ranges. Actual costs vary by supplier and location.")
            Spacer(Modifier.height(8.dp))
        }
        items(ideas) { idea ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Text("• $idea", Modifier.padding(16.dp))
            }
        }
    }
}

fun money(value: Double): String =
    String.format(Locale.US, "%,.2f", value)
